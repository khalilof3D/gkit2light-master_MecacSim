# Physical Model Animation
An animated falling scarf with collisions using gkit2light library which is a library inspired by OpenGL.

To compile: make in gkit2light directory.
To execute: ./go in the gkit2light directory.

![scene](./screenshots/finalscene.png)
