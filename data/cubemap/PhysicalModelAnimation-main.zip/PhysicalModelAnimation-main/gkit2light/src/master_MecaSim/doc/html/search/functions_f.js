var searchData=
[
  ['transpose_376',['Transpose',['../class_matrix.html#a350d12361c31ec650e667e8120da7274',1,'Matrix']]],
  ['transposeconst_377',['TransposeConst',['../class_matrix.html#a8240391058b682d16c1acd8097dc79b2',1,'Matrix']]]
];
