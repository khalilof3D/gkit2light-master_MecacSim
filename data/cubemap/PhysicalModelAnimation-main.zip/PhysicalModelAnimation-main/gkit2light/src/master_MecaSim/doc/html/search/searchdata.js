var indexSectionsWithContent =
{
  0: "_abcdfghilmnopqrstuvwxy~",
  1: "fmnoprstv",
  2: "cmnopsv",
  3: "abcdghilmnopqrstuv~",
  4: "_abcdfhmnpruvwxy",
  5: "l",
  6: "gm",
  7: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Macros",
  7: "Pages"
};

