var searchData=
[
  ['texture_208',['Texture',['../struct_texture.html',1,'']]],
  ['transpose_209',['Transpose',['../class_matrix.html#a350d12361c31ec650e667e8120da7274',1,'Matrix']]],
  ['transposeconst_210',['TransposeConst',['../class_matrix.html#a8240391058b682d16c1acd8097dc79b2',1,'Matrix']]]
];
